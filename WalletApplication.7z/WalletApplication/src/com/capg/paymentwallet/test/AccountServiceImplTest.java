package com.capg.paymentwallet.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class AccountServiceImplTest {
    CustomerBean customer = new CustomerBean();
    private static IAccountService service=null;

    @BeforeClass
    
    public static void createinstance() {
                    service = new AccountServiceImpl();
    }

	@Test
	public void testCreateAccount() {
		
	}

}
