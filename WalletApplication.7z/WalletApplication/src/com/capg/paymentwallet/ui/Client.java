package com.capg.paymentwallet.ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.WalletTransaction;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class Client {
	   
	IAccountService service=new AccountServiceImpl();
	CustomerBean customer=new CustomerBean();
	Scanner scanner=new Scanner(System.in);
	
	
	
	public static void main(String[] args) throws Exception {
		IAccountService service=new AccountServiceImpl();
		char ch;
		Client client=new  Client();
		
		while(true)
		{
		System.out.println("****WELCOME****");
		System.out.println("1. Create Account ");
		System.out.println("2.  Deposite  ");
		System.out.println("3. Withdraw ");
		System.out.println("4. Show Balance ");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		System.out.println("7. Exit");
		System.out.println("Choose an option");
		int option =client. scanner.nextInt();
		
		switch (option) {
		case 1:
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter Customer firstname");
			String firstName=scanner.next();
			System.out.println("Enter Customer lastname");
			String lastName=scanner.next();
			System.out.println("Enter  Customer  email id");
			String email=scanner.next();
			System.out.println("Enter  Customer  phone number");
			String phone=scanner.next();
			System.out.println("Enter  Customer PAN number");
			String pan=scanner.next();
			System.out.println("Enter  Customer  address");
			String address=scanner.next();
			CustomerBean customerBean=new CustomerBean();
			customerBean.setAddress(address);
			customerBean.setEmailId(email);
			customerBean.setPanNum(pan);
			customerBean.setPhoneNo(phone);
			customerBean.setFirstName(firstName);
			customerBean.setLastName(lastName);
			Random random=new Random();
			int cId=(int)(Math.random()*10000);
			customerBean.setcId(cId);
			
			System.out.println("Enter balance to create account");
			double balance=scanner.nextDouble();
			AccountBean accountBean=new AccountBean();
			accountBean.setBalance(balance);
			accountBean.setInitialDeposit(balance);
			accountBean.setCustomerBean(customerBean);
			boolean result=service.createAccount(accountBean);
			if(result)
			{
				System.out.println(" Account has been created ");
			}
			else
			{
				System.out.println("Please Enter valid details ");
			}
               break;
		case 2:
			Scanner sc=new Scanner(System.in);
			CustomerBean customer=new CustomerBean();
			System.out.println("Enter Account ID");
			int accId=sc.nextInt();
			AccountBean accountBean1=service.findAccount(accId);
			System.out.println("Enter amount that you want to deposit");
			double depositAmt=sc.nextDouble();
			WalletTransaction wt=new WalletTransaction();
			wt.setTransactionType(1);
			wt.setTransactionDate(new Date());
			wt.setTransactionAmt(depositAmt);
			wt.setBeneficiaryAccountBean(null);
			accountBean1.addTransation(wt);
			if(accountBean1==null)
				System.out.println(" Account Does not Exist");
			boolean value=service.deposit(accountBean1, depositAmt);
			if(value){
				System.out.println("Deposited Money into Account ");
			}else{
				System.out.println("NOT Deposited Money into Account ");
			}
			

			break;

		case 3:
			Scanner sc1=new Scanner(System.in);
			System.out.println("Enter Account ID");
			int accId1=sc1.nextInt();
			AccountBean accountBean2=service.findAccount(accId1);
			System.out.println("Enter amount that you want to withdraw");
			double withdrawAmt=sc1.nextDouble();
			WalletTransaction wt1=new WalletTransaction();
			wt1.setTransactionType(2);
			wt1.setTransactionDate(new Date());
			wt1.setTransactionAmt(withdrawAmt);
			wt1.setBeneficiaryAccountBean(null);
			accountBean2.addTransation(wt1);
			if(accountBean2==null)
				System.out.println("Account Does not exist");
			boolean Value=service.withdraw(accountBean2, withdrawAmt);
			if(Value){
				System.out.println("Withdaw Money from Account done");
			}else{
				System.out.println("Withdaw Money from Account -Failed ");
			}
			
			break;
			
			
		case 4:client.showBalance();

			   break;
		case 5:client.fundTransfer();

			break;
		case 6:client.printTransaction();

			break;
		case 7:System.exit(0);

			break;
			
			
		default:System.out.println("invalid option");
			break;
		}
		
	
		}
	}
	
	
	void showBalance() throws CustomerException, Exception 
	{
		System.out.println("Enter Account ID");
		int accId=scanner.nextInt();
		AccountBean accountBean=service.findAccount(accId);
		if(accountBean==null){
			System.out.println("Account Does not exist");
			return ;
		}
		
		double balance=accountBean.getBalance();
		System.out.println("Your balance is: " +balance);
	}
	
	void fundTransfer() throws Exception
	{
		System.out.println("Enter Account ID to Transfer Money From");
		int srcAccId=scanner.nextInt();
		AccountBean accountBean1=service.findAccount(srcAccId);
		System.out.println("Enter Account ID to Transfer Money to");
		int targetAccId=scanner.nextInt();
		AccountBean accountBean2=service.findAccount(targetAccId);
		System.out.println("Enter amount that you want to transfer");
		double transferAmt=scanner.nextDouble();
		WalletTransaction wt=new WalletTransaction();
		wt.setTransactionType(3);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(transferAmt);
		wt.setBeneficiaryAccountBean(accountBean2);
		accountBean1.addTransation(wt);
		boolean result=service.fundTransfer(accountBean1, accountBean2, transferAmt);
		
		if(result){
			System.out.println("Transfering Money from Account done");
		}else{
			System.out.println("Transfering Money from Account Failed ");
		}
		
	}
	
	
	void printTransaction() throws Exception
	{
		System.out.println("Enter Account ID (for printing Transaction Details");
		int accId=scanner.nextInt();
		
		AccountBean accountBean=service.findAccount(accId);
		
		List<WalletTransaction>  transactions=accountBean.getAllTransactions();
		
		System.out.println(accountBean);
		System.out.println(accountBean.getCustomerBean());
		System.out.println("Your Transcations are:");
		
		
		for(WalletTransaction wt:transactions){
			
			String str="";
			if(wt.getTransactionType()==1){
				str=str+"DEPOSIT";
			}
			if(wt.getTransactionType()==2){
				str=str+"WITHDRAW";
			}
			if(wt.getTransactionType()==3){
				str=str+"FUND TRANSFER";
			}
			
			str=str+"\t\t"+wt.getTransactionDate();
			
			str=str+"\t\t"+wt.getTransactionAmt();
			System.out.println(str);
		}
		
	
	}
	
	    
	
}
