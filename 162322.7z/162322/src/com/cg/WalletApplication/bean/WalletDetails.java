/*package com.cg.WalletApplication.bean;

import java.awt.Window.Type;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="wallet_details")
public class WalletDetails {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int walletId;


@Temporal(TemporalType.DATE)
private Date walletOpeningDate;

private List<TranscationDetails> allTranscations;
private double balance;




@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
private CustomerDetails customerBean;

public int getWalletId() {
	return walletId;
}

public void setWalletId(int walletId) {
	this.walletId = walletId;
}

public Date getWalletOpeningDate() {
	return walletOpeningDate;
}

public void setWalletOpeningDate(Date walletOpeningDate) {
	this.walletOpeningDate = walletOpeningDate;
}

public List<TranscationDetails> getAllTranscations() {
	return allTranscations;
}

public void setAllTranscations(List<TranscationDetails> allTranscations) {
	this.allTranscations = allTranscations;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public CustomerDetails getCustomerBean() {
	return customerBean;
}

public void setCustomerBean(CustomerDetails customerBean) {
	this.customerBean = customerBean;
}



@Override
public String toString() {
	return "WalletDetails [walletId=" + walletId + ", walletOpeningDate="
			+ walletOpeningDate + ", allTranscations=" + allTranscations
			+ ", balance=" + balance + ", customerBean=" + customerBean + "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + walletId;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	WalletDetails other = (WalletDetails) obj;
	if (walletId != other.walletId)
		return false;
	return true;
}





}
*/