/*package com.cg.WalletApplication.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
@Entity
@Table(name="transcation_details")
public class TranscationDetails {
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transcationId;
	
	
	private double transcationAmount;
	private int transcationType;
	
	@Temporal(TemporalType.DATE)
	private Date transcationDate;
	
	@Transient
	private WalletDetails walletBean;
	
	
	

	
	public int getTranscationId() {
		return transcationId;
	}

	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}

	public double getTranscationAmount() {
		return transcationAmount;
	}

	public void setTranscationAmount(double transcationAmount) {
		this.transcationAmount = transcationAmount;
	}

	public int getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(int transcationType) {
		this.transcationType = transcationType;
	}

	public Date getTranscationDate() {
		return transcationDate;
	}

	public void setTranscationDate(Date transcationDate) {
		this.transcationDate = transcationDate;
	}

	public WalletDetails getWalletBean() {
		return walletBean;
	}

	public void setWalletBean(WalletDetails walletBean) {
		this.walletBean = walletBean;
	}

	
	
	
	
	@Override
	public String toString() {
		return "TranscationDetails [transcationId=" + transcationId
				+ ", transcationAmount=" + transcationAmount
				+ ", transcationType=" + transcationType + ", transcationDate="
				+ transcationDate + ", walletBean=" + walletBean + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + transcationId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TranscationDetails other = (TranscationDetails) obj;
		if (transcationId != other.transcationId)
			return false;
		return true;
	}

	
	
	

}
*/