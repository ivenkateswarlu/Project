package com.cg.WalletApplication.exception;

public class CustomerExceptionMessage {

	public static final String ERROR1 = null;
	public static final String ERROR2 = null;
	public static final String ERROR3 = null;
	public static final String ERROR5 = null;
	public static final String ERROR4 = null;
	public static final String ERROR7 = null;
	public static final String ERROR6 = null;
	public static final String ERROR10 = null;
	
	

}
