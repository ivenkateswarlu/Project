package com.cg.WalletApplication.exception;

public class CustomerExceptionMessage {

	public static final String ERROR1 = "Enter valid first Name";
	public static final String ERROR2 = "Enter Valid Last Name";
	public static final String ERROR3 = "Enter valid Emial";
	public static final String ERROR5 = "Enter Valid Phone Number";
	public static final String ERROR4 = "Enter Valid PAN number";
	public static final String ERROR7 = null;
	public static final String ERROR6 = "Enter Amount greater than 500";
	public static final String ERROR10 = null;
	
	

}
