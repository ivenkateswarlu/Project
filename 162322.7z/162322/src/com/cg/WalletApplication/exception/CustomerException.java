package com.cg.WalletApplication.exception;

public class CustomerException extends Exception{

	public CustomerException(String error1) {
		// TODO Auto-generated constructor stub
	}

}
