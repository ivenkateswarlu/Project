package com.cg.WalletApplication.dao;

import javax.persistence.EntityManager;

import com.cg.WalletApplication.bean.CustomerDetails;

public class DAOImpl implements IDAO {

	EntityManager em;
	CustomerDetails ref=new CustomerDetails();
	
	
	@Override
	public boolean createAccount(CustomerDetails customerDetails) {
		EntityManager em=null;
		em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		
		em.persist(customerDetails);
		
		em.getTransaction().commit();
		JPAManager.closeResources(em);
		
		return true;
	}

	@Override
	public boolean deposite(String phoneNumber, double amount) {
		this.em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		
			ref=em.find(CustomerDetails.class,phoneNumber);
			if(ref.getPhoneNumber()!=phoneNumber){
				return false;
			}
			else{
				double balance = ref.getBalance() + amount;
				ref.setBalance(balance);
				
				em.getTransaction().commit();
				JPAManager.closeResources(em);
				return true;
			}
			
			
	
		
		
	}

	@Override
	public boolean withdraw(String number, double amt) {

		this.em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		
			ref=em.find(CustomerDetails.class,number);
			if(ref.getPhoneNumber().equals(number) && ref.getBalance()>amt){
				
				double balance = ref.getBalance()-amt;
				ref.setBalance(balance);
				em.getTransaction().commit();
				JPAManager.closeResources(em);
				return true;
			}
			
	else{
			return false;
				}
		

	}

}
