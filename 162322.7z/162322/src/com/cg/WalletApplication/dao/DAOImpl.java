package com.cg.WalletApplication.dao;

import java.util.Date;

import javax.persistence.EntityManager;

import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.bean.TranscationDetails;

public class DAOImpl implements IDAO {

	EntityManager em;
	
	
	
	@Override
	public boolean createAccount(CustomerDetails customerDetails) {
		EntityManager em=null;
		em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		
		em.persist(customerDetails);
		
		em.getTransaction().commit();
		JPAManager.closeResources(em);
		
		return true;
	}

	@Override
	public boolean deposite(int accId, double amount) {
		em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		CustomerDetails ref;
			ref=em.find(CustomerDetails.class,accId);
			if(ref!=null){
				double balance = ref.getBalance() + amount;
				TranscationDetails details=new TranscationDetails();
				details.setTranscationAmount(amount);
				details.setTranscationDate(new Date());
				details.setTranscationType("Deposit");
				ref.addTransation(details);
				ref.setBalance(balance);
				em.merge(ref);
				em.getTransaction().commit();
				JPAManager.closeResources(em);	
				return true;
				}
			else{
				return false;
			}
	}

	@Override
	public boolean withdraw(int accoId, double amount) {
		
		em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		CustomerDetails ref=new CustomerDetails();
			ref=em.find(CustomerDetails.class,accoId);
			double balance=0;
			if(ref!=null){
				if(amount<ref.getBalance()){
				balance= ref.getBalance() - amount;
				ref.setBalance(balance);
				TranscationDetails details=new TranscationDetails();
				details.setTranscationAmount(amount);
				details.setTranscationDate(new Date());
				details.setTranscationType("withdraw");
	
				em.merge(ref);
				em.getTransaction().commit();
				JPAManager.closeResources(em);	
				return true;
				}
			else{
				return false;
			}
			}else
				return false;
			
	}

	@Override
	public boolean fundTransfer(int sourceAccountId, int targetAccountId,
			double am) {
		boolean isvalid=false;
		em=JPAManager.createEntityManager();
		em.getTransaction().begin();
		CustomerDetails ref=new CustomerDetails();
		CustomerDetails dest=new CustomerDetails();
		ref=em.find(CustomerDetails.class,sourceAccountId);
		double balance=0;
		if(ref!=null){
			dest=em.find(CustomerDetails.class,targetAccountId);
			if(ref!=null){
				if(am<ref.getBalance()){
				balance = ref.getBalance() - am;
				ref.setBalance(balance);
				double bal=dest.getBalance()+am;
				dest.setBalance(bal);
				TranscationDetails details=new TranscationDetails();
				details.setTranscationAmount(am);
				details.setTranscationDate(new Date());
				details.setTranscationType("withdraw");
				em.merge(ref);
				em.merge(dest);
				em.getTransaction().commit();
				JPAManager.closeResources(em);	
				}else {
					return false;
				}
			}
			else{
				return isvalid=false;
			}
		}
		else{
			return isvalid=false;
		}
		return isvalid=true;
	}

	@Override
	public double showBalance(int number) {
		em=JPAManager.createEntityManager();
		CustomerDetails ref=new CustomerDetails();
		double balance=0.0;
		ref=em.find(CustomerDetails.class,number);
		if(ref!=null){
			balance = ref.getBalance();
			JPAManager.closeResources(em);	
		
			}
		
		return balance;
		
		
	}
	public CustomerDetails print(int accid){
		em=JPAManager.createEntityManager();
		CustomerDetails ref=new CustomerDetails();
		ref=em.find(CustomerDetails.class, accid);
		return ref;
	}

	
}	

