package com.cg.WalletApplication.dao;

import com.cg.WalletApplication.bean.CustomerDetails;

public interface IDAO {

	public boolean createAccount(CustomerDetails customerDetails);

	public boolean deposite(int accId, double amount);

	public boolean withdraw(int accoId, double amt);

	public boolean fundTransfer(int sourceAccountId, int targetAccountId,
			double am);

	public double showBalance(int number);

}
