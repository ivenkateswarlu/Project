package com.cg.WalletApplication.dao;

import com.cg.WalletApplication.bean.CustomerDetails;

public interface IDAO {

	public boolean createAccount(CustomerDetails customerDetails);

	public boolean deposite(String phoneNumber, double amount);

	public boolean withdraw(String number, double amt);

}
