package com.cg.WalletApplication.ui;

import java.util.Random;
import java.util.Scanner;
import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.exception.CustomerException;
import com.cg.WalletApplication.exception.CustomerExceptionMessage;
import com.cg.WalletApplication.service.CustomerServiceImpl;
import com.cg.WalletApplication.service.ICustomerService;

public class Client {
	static ICustomerService service=new CustomerServiceImpl();
	static CustomerDetails customerDetails=new CustomerDetails();
	

	public static void main(String[] args) throws CustomerException {
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("***WELCOME***");
		while(true){
			System.out.println("1) Create Account");
			System.out.println("2) Deposit");
			System.out.println("3) WithDrawl");
			System.out.println("4) Fund Transfer");
			System.out.println("5) Show Balance");
			System.out.println("6) Print Transcations");
			System.out.println("7) Exit");
			System.out.println("Enter your Choice");
			int option=scanner.nextInt();
			
			
			switch (option) {
			
			case 1:
				
				
				System.out.println("Enter Account Holder FirstName");
				String firstName=scanner.next();
				customerDetails.setFirstName(firstName);
				System.out.println("Enter Account Holder Lastname");
				String lastName=scanner.next();
				customerDetails.setLastName(lastName);
				System.out.println("Enter  Customer  email id");
				String email=scanner.next();
				customerDetails.setEmailId(email);
				System.out.println("Enter  Customer  phone number");
				String phone=scanner.next();
				customerDetails.setPhoneNumber(phone);
				System.out.println("Enter  Customer PAN number");
				String pan=scanner.next();
				customerDetails.setPanNumber(pan);
				System.out.println("Enter  Customer  address");
				String address=scanner.next();
				customerDetails.setAddress(address);
				
				System.out.println("Enter Opening Balance to create account");
				double balance=scanner.nextDouble();
				customerDetails.setDepositInitialBalance(balance);
				
		
				boolean result=service.createAccount(customerDetails);
				if(result)
					System.out.println(" Account has been created ");
				else
				{
					System.out.println("Please Enter valid details ");
				}
	               break;
				
			case 2:
				
				
				System.out.println("enter the phoneNumber");
				String phoneNumber=scanner.next();
				System.out.println("enter the amount to deposit");
				double amount=scanner.nextDouble();
				result=service.deposit(phoneNumber, amount);
				if(result)
					System.out.println("deposited successfully");
				else
					throw new CustomerException(CustomerExceptionMessage.ERROR10);
				break;
			
			case 3:
				System.out.println("enter the phoneNumber");
				String number=scanner.next();
				System.out.println("enter the amount to deposit");
				double amt=scanner.nextDouble();
				result=service.withdraw(number, amt);
				if(result)
					System.out.println("amount is withdrawed");
				else
					throw new CustomerException(CustomerExceptionMessage.ERROR10);
				break;
			case 7:
				System.exit(0);
				break;
				
			default:
				break;
			}
			
		}
		
		
		
		
	}

}
