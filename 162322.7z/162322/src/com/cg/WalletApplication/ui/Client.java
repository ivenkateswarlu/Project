package com.cg.WalletApplication.ui;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.bean.TranscationDetails;
import com.cg.WalletApplication.exception.CustomerException;
import com.cg.WalletApplication.exception.CustomerExceptionMessage;
import com.cg.WalletApplication.service.CustomerServiceImpl;
import com.cg.WalletApplication.service.ICustomerService;

public class Client {

	public static void main(String[] args) throws CustomerException {
		ICustomerService service = new CustomerServiceImpl();
		CustomerDetails customerDetails = new CustomerDetails();
		Scanner scanner = new Scanner(System.in);
		System.out.println("***WELCOME***");
		while (true) {
			System.out.println("1) Create Account");
			System.out.println("2) Deposit");
			System.out.println("3) WithDrawl");
			System.out.println("4) Fund Transfer");
			System.out.println("5) Show Balance");
			System.out.println("6) Print Transcations");
			System.out.println("7) Exit");
			System.out.println("Enter your Choice");
			int option = scanner.nextInt();

			switch (option) {

			case 1:

				System.out.println("Enter Account Holder FirstName");
				String firstName = scanner.next();
				customerDetails.setFirstName(firstName);
				System.out.println("Enter Account Holder Lastname");
				String lastName = scanner.next();
				customerDetails.setLastName(lastName);
				System.out.println("Enter  Customer  email id");
				String email = scanner.next();
				customerDetails.setEmailId(email);
				System.out.println("Enter  Customer  phone number");
				String phone = scanner.next();
				customerDetails.setPhoneNumber(phone);
				System.out.println("Enter  Customer PAN number");
				String pan = scanner.next();
				customerDetails.setPanNumber(pan);
				System.out.println("Enter  Customer  address");
				String address = scanner.next();
				customerDetails.setAddress(address);

				System.out.println("Enter Opening Balance to create account");
				double balance = scanner.nextDouble();
				customerDetails.setDepositInitialBalance(balance);
				customerDetails.setBalance(balance);

				boolean result = service.createAccount(customerDetails);
				if (result)
					System.out.println(" Account has been created ");
				else {
					System.out.println("Please Enter valid details ");
				}
				break;

			case 2:

				CustomerDetails customerDetails1 = new CustomerDetails();
				System.out.println("enter the accountId");
				int accId = scanner.nextInt();
				System.out.println("enter the amount to deposit");
				double amount = scanner.nextDouble();
				if (amount > 0) {

					
					if (service.deposit(accId, amount)) {
						System.out.println("deposited successfully");

					} else
						
						System.out.println("Money is not deposited");
				}

				break;
			case 3:
				System.out.println("enter the accountId");
				int accoId = scanner.nextInt();
				System.out.println("enter the amount to withdraw");
				double amt = scanner.nextDouble();
				if (amt > 0) {
			

					result = service.withdraw(accoId, amt);

					if (result)
						System.out.println("amount is withdrawed");
					else
						System.err.println("Check The Balance");
					
				
				}
					break;
				
			case 4:
				System.out.println("enter Source AccountId");
				int sourceAccountId = scanner.nextInt();
				System.out.println("Enter Target AccountId");
				int targetAccountId = scanner.nextInt();
				System.out.println("enter the amount to deposit");
				double am = scanner.nextDouble();
				if(am>0 ){
					if(service.fundTransfer(sourceAccountId, targetAccountId,am)){
						System.out.println("FundTransfer is success");
						
					}
					else
						System.err.println("FundTransferFailed");
					
				}
				else
					System.err.println("Check The Balance");
				break;

			case 5:
				System.out.println("Enter Account ID to Dislay account Balance");
				int number = scanner.nextInt();
				double finalAmount = service.showBalance(number);
				System.out.println("Money in your account is:" + finalAmount);

			case 6:
				System.out.println("Enter Account Id");
				int accid = scanner.nextInt();
				CustomerDetails customerDetails2 = service.print(accid);

				List<TranscationDetails> trans = customerDetails2
						.getAllTranscations();
				for (TranscationDetails transcationDetails : trans) {
					System.out.println(transcationDetails);

				}

				break;
			case 7:
				System.exit(0);
				break;

			default:
				break;
			}

		}

	}
}
