package com.cg.WalletApplication.service;

import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.exception.CustomerException;

public interface ICustomerService {
	
	
	public boolean createAccount(CustomerDetails customerDetails) throws CustomerException;

	public boolean deposit(String phoneNumber, double amount);

	public boolean withdraw(String number, double amt);

}
