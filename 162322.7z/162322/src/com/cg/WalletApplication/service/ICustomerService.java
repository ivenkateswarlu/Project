package com.cg.WalletApplication.service;

import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.exception.CustomerException;

public interface ICustomerService {
	
	

	public boolean createAccount(CustomerDetails customerDetails) throws CustomerException;

	public boolean deposit(int accId, double amount);

	public boolean withdraw(int accoId, double amt);

	public boolean fundTransfer(int sourceAccountId, int targetAccountId,
			double am);

	public double showBalance(int number);

	public CustomerDetails print(int accid);
	

}
