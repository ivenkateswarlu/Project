package com.cg.WalletApplication.service;

import com.cg.WalletApplication.bean.CustomerDetails;
import com.cg.WalletApplication.dao.DAOImpl;
import com.cg.WalletApplication.dao.IDAO;
import com.cg.WalletApplication.exception.CustomerException;
import com.cg.WalletApplication.exception.CustomerExceptionMessage;

public class CustomerServiceImpl implements ICustomerService {

	IDAO dao=new DAOImpl();
	
	@Override
	public boolean createAccount(CustomerDetails customerDetails) throws CustomerException {
		
		boolean result=validate(customerDetails);
		if(result)
			result=dao.createAccount(customerDetails);
		return result;
	}
	
	
	public boolean validate(CustomerDetails customerDetails) throws CustomerException{
		
		boolean valid = true;
		if (!(customerDetails.getFirstName()
				.matches("[A-Za-z]{4,}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		if (!(customerDetails.getLastName()
				.matches("[A-Za-z]{4,}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR2);
		}

		if (!(customerDetails.getEmailId()
				.matches("[a-z_A-Z0-9]+@+[a-z]+\\.com"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
		}
		if (!(customerDetails.getPhoneNumber()
				.matches("^[4-9][0-9]{9}$"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR5);
		}
		if (!(customerDetails.getPanNumber().length() == 10)) {
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		/*if (!(customerDetails.getAddress()== null)) {
			throw new CustomerException(CustomerExceptionMessage.ERROR7);
		}
*/
		if (!(customerDetails.getDepositInitialBalance() > 500)) {
			throw new CustomerException(CustomerExceptionMessage.ERROR6);
		}

		return valid;
		
	
		
	}


	@Override
	public boolean deposit(String phoneNumber, double amount) {
		
		return dao.deposite(phoneNumber,amount);
	}


	@Override
	public boolean withdraw(String number, double amt) {
		// TODO Auto-generated method stub
		return dao.withdraw(number,amt);
	}

}
