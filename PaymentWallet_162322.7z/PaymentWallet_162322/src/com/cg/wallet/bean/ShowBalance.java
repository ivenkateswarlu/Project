package com.cg.wallet.bean;

import java.math.BigInteger;

public class ShowBalance {
	
private BigInteger phoneNumber;

public BigInteger getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(BigInteger phoneNumber) {
	this.phoneNumber = phoneNumber;
}

}
