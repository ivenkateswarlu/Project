package com.cg.wallet.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;

public class DepositeBean {
	
	private LocalDate depositeDate;
	  private LocalTime depositTime;
	  private BigInteger phNumber;
	  private double depoAmount;
	  private double balanceAfterDeposit;
	  
	  
  public LocalDate getDate() {
		return depositeDate;
	}
	public void setDate(LocalDate date) {
		this.depositeDate = date;
	}
	public LocalTime getTime() {
		return depositTime;
	}
	public void setTime(LocalTime time) {
		this.depositTime = time;
	}
	public BigInteger getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(BigInteger phNumber) {
		this.phNumber = phNumber;
	}
	public double getDepoAmount() {
		return depoAmount;
	}
	public void setDepoAmount(double depoAmount) {
		this.depoAmount = depoAmount;
	}
	public double getBalanceAfterDeposit() {
		return balanceAfterDeposit;
	}
	public void setBalanceAfterDeposit(double balanceAfterDeposit) {
		this.balanceAfterDeposit = balanceAfterDeposit;
	}

  
}
