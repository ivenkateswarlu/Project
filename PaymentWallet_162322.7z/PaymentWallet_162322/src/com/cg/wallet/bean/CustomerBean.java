package com.cg.wallet.bean;

import java.math.BigInteger;

public class CustomerBean {

	private double balance;
	private String fName;
	private String lName;
	private String email;
	private String address;
	private BigInteger pNumber;
	
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public BigInteger getpNumber() {
		return pNumber;
	}
	public void setpNumber(BigInteger pNumber) {
		this.pNumber = pNumber;
	}
	
	
}
