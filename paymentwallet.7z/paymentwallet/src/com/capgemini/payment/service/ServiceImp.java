package com.capgemini.payment.service;

import java.util.List;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.dao.DAOImp;
import com.capgemini.payment.dao.IDAO;
import com.capgemini.payment.exception.PaymentException;
import com.capgemini.payment.exception.PaymentExceptionMessage;

public class ServiceImp implements IService {
	IDAO dao=new DAOImp();

	@Override
	public boolean validate(CustomerBean c) throws PaymentException {
		// TODO Auto-generated method stub
		boolean isValid=true;
		if(c.getCustomerName()==null)
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR1);
		}
		if((c.getCustomerName().trim().length()<3))
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR2);
		}
		if(!(c.getCustomerName().matches("[a-zA-Z]*")))
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR4);
		}
		if(c.getCustomerAge()<10)
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR3);
		}
		
		if(c.getCustomerBalance()<0)
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR5);
		}
		if(!(c.getAccountNumber().trim().length()==10))
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR8);
		}
		if(!(c.getAccountNumber().matches("[6-9][0-9]{9}")))
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR6);
		}
		
		if(c.getAccountNumber()==null)
		{
			isValid=false;
			throw new PaymentException(PaymentExceptionMessage.ERROR7);
		}
		isValid=true;
		return isValid;
	}

	@Override
	public boolean createAccount(CustomerBean c) throws PaymentException {
		// TODO Auto-generated method stub
		boolean result=validate(c);
		if(result)
			result=dao.createAccount(c);
		return result;
	}

	@Override
	public CustomerBean showBalance(String phoneNumber) throws PaymentException {
		// TODO Auto-generated method stub
		return dao.showBalance(phoneNumber);
	}

	@Override
	public List<TranscationBean> printTranscations() {
		// TODO Auto-generated method stub
		return dao.printTranscations();
	}

	@Override
	public boolean deposit(String phoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		return dao.deposit(phoneNumber, amount);
	}

	@Override
	public boolean withDraw(String phoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		return dao.withDraw(phoneNumber, amount);
	}

	@Override
	public boolean fundTransfer(String sourcePhoneNumber,
			String targetPhoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		return dao.fundTransfer(sourcePhoneNumber, targetPhoneNumber, amount);
	}
}
