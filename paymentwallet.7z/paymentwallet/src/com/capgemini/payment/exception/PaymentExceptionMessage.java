package com.capgemini.payment.exception;

public class PaymentExceptionMessage {
	//message
	public static final String ERROR1="Name Should Not Be Empty";
	public static final String ERROR2="Name Should Minimum Of Length 3";
	public static final String ERROR3="Age Should Greater Than 9";
	public static final String ERROR4="Name Should Be In Only Alphabets";
	public static final String ERROR5="Balance Should Not Be In Negetive Number";
	public static final String ERROR6="Phone Number Should In Start From 6-9";
	public static final String ERROR7="Phone Number Should Be Empty";
	public static final String ERROR8="Phone Number Should Be Length of 10";
	public static final String ERROR9="Account Not Created";
	public static final String ERROR10="Amount Not Deposited";
	public static final String ERROR11="Amount Not WithDrawl";
	public static final String ERROR15="Fund Transfer Failed";
	public static final String ERROR12="Check the Source PhoneNumber";
	public static final String ERROR13="Check the Target PhoneNumber";
	public static final String ERROR14="Check the PhoneNumber";
}
