package com.capgemini.payment.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.exception.PaymentException;

public class DAOImp implements IDAO {

	List<CustomerBean> customerDetails = new ArrayList<CustomerBean>();
	List<TranscationBean> transcationDetails = new ArrayList<TranscationBean>();

	@Override
	public boolean createAccount(CustomerBean c) {
		// TODO Auto-generated method stub
		boolean isValid = customerDetails.add(c);
		return isValid;
	}

	@Override
	public CustomerBean showBalance(String phoneNumber) throws PaymentException {
		// TODO Auto-generated method stub
		CustomerBean bean = null;
		for (CustomerBean customerBean : customerDetails) {
			if (customerBean.getAccountNumber().equals(phoneNumber))
				bean = customerBean;
		}
		return bean;
	}

	@Override
	public List<TranscationBean> printTranscations() {
		// TODO Auto-generated method stub
		return transcationDetails;
	}

	@Override
	public boolean deposit(String phoneNumber, double amount)
			throws PaymentException {
		// TODO Auto-generated method stub
		boolean isValid = false;
		if (amount > 0)
		{
			for (CustomerBean customerBean : customerDetails) 
			{
				if (customerBean.getAccountNumber().equals(phoneNumber))
				{
					double balance = customerBean.getCustomerBalance() + amount;
					customerBean.setCustomerBalance(balance);
					customerDetails.add(customerBean);
					TranscationBean bean = new TranscationBean();
					bean.setNumber(customerBean.getAccountNumber());
					bean.setDeposit(amount);
					bean.setTranscationType("deposit");
					bean.setTranscationTime(new Date());
					bean.setWithdrawl(0);
					transcationDetails.add(bean);
					isValid = true;
					break;
				}
			}
		}
		else
			isValid = false;
		return isValid;
	}

	@Override
	public boolean withDraw(String phoneNumber, double amount)
			throws PaymentException {
		// TODO Auto-generated method stub
		boolean isValid = false;
		if (amount > 0)
		{
			for (CustomerBean customerBean : customerDetails) 
			{
				if (customerBean.getAccountNumber().equals(phoneNumber))
				{
					double balance = customerBean.getCustomerBalance() - amount;
					customerBean.setCustomerBalance(balance);
					customerDetails.add(customerBean);
					TranscationBean bean = new TranscationBean();
					bean.setNumber(customerBean.getAccountNumber());
					bean.setDeposit(0);
					bean.setTranscationType("withdrwal");
					bean.setTranscationTime(new Date());
					bean.setWithdrawl(amount);
					transcationDetails.add(bean);
					isValid = true;
					break;
				}
			}
		}
		else
			isValid = false;
		return isValid;
	}

	@Override
	public boolean fundTransfer(String sourcePhoneNumber,
			String targetPhoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		boolean isValid = false;
		CustomerBean source = null;
		CustomerBean target = null;
		for (CustomerBean customerBean : customerDetails) {
			if (customerBean.getAccountNumber().equals(sourcePhoneNumber))
				source = customerBean;
			if (customerBean.getAccountNumber().equals(targetPhoneNumber))
				target = customerBean;
		}
		if (source != null) 
		{
			double balance = source.getCustomerBalance() - amount;
			if (balance >= 0) 
			{
				source.setCustomerBalance(balance);
				customerDetails.add(source);
				if (target.getAccountNumber().equals(targetPhoneNumber)) 
				{
					target.setCustomerBalance(target.getCustomerBalance()
							+ amount);
					customerDetails.add(target);
					TranscationBean targetBean = new TranscationBean();
					targetBean.setNumber(target.getAccountNumber());
					targetBean.setDeposit(amount);
					targetBean.setTranscationType("fund Transfer");
					targetBean.setTranscationTime(new Date());
					targetBean.setWithdrawl(0);
					transcationDetails.add(targetBean);
					
					//withdrawl from source account.copy to transcation
					
					TranscationBean sourceBean = new TranscationBean();
					sourceBean.setNumber(source.getAccountNumber());
					sourceBean.setDeposit(0);
					sourceBean.setTranscationType("fund Transfer");
					sourceBean.setTranscationTime(new Date());
					sourceBean.setWithdrawl(amount);
					transcationDetails.add(sourceBean);
					isValid = true;
				} 
				else 
				{
					source.setCustomerBalance(balance + amount);
					customerDetails.add(source);
					isValid = false;
				}
			} 
			else
				isValid=false;
		} 
		else
			isValid=false;
		return isValid;
	}
}
